public class Song{
  String title;
  String artist;
  String genre;
  
  public Song(String title, String artist, String genre){
        title = material;
        artist = artist;
        genre = genre;
  }
}