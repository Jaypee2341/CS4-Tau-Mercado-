public class Singer{
    String name;
    int noOfPerformances;
    Song favoriteSong;
    double earnings;
}